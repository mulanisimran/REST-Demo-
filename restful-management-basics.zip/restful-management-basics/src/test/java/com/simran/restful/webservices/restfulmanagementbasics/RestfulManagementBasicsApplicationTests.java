package com.simran.restful.webservices.restfulmanagementbasics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulManagementBasicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
