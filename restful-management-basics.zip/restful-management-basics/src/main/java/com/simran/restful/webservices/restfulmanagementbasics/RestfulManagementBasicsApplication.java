package com.simran.restful.webservices.restfulmanagementbasics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulManagementBasicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulManagementBasicsApplication.class, args);
	}

}
